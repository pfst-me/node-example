var express = require("express");
var router = express.Router();

const scholar = require("../controllers/scholarship.controller.js");

// Create a new User
router.post("/createScholar", scholar.create);

// Retrieve all Tutorials
router.get("/getAllScholarData", scholar.findAll);

// Retrieve a single User with id
router.get("/getScholarData/:cardNumber", scholar.findOne);

// Update a User with id
router.put("/updateScholarData/:id", scholar.update);

//

//

//

//

//Retrieve users account already expired or inactive
router.get("/getInactiveUsers", scholar.getInactive);

// Delete a User with id
router.delete("/deleteUser/:id", scholar.delete);

// Create a new User
router.delete("/deleteUser", scholar.deleteAll);

// Retrieve all published Users
router.get("/published", scholar.findAllPublished);

module.exports = router;

// app.use("/api/bms", router);
