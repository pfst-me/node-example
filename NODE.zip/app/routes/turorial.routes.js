var express = require("express");
var router = express.Router();

const user = require("../controllers/user.controller.js");

// Create a new User
router.post("/createUser", user.create);

// Retrieve all Tutorials
router.get("/getUsers", user.findAll);

// Retrieve a single User with id
router.get("/getUsers/:id", user.findOne);

// Update a User with id
router.put("/updateUser/:id", user.update);

// Retrieve users which account is expiring soon
router.get("/getExpiringUsers", user.findExpiring);

//Retrieve users account already expired or inactive
router.get("/getInactiveUsers", user.getInactive);

// Delete a User with id
router.delete("/deleteUser/:id", user.delete);

// Create a new User
router.delete("/deleteUser", user.deleteAll);

// Retrieve all published Users
router.get("/published", user.findAllPublished);

module.exports = router;

// app.use("/api/bms", router);
