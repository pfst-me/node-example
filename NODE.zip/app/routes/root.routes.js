var express = require("express");
var rootRouter = express.Router();

var user = require("./turorial.routes.js");
var scholar = require("./scholar.routes.js");

rootRouter.use("/user", user);
rootRouter.use("/scholar", scholar);

module.exports = rootRouter;
