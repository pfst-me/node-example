const db = require("../models");
const CreateScholar = db.scholarinfo;

// Create and Save a new User
exports.create = (req, res) => {
  // Validate request
  if (!req.body.cardNumber) {
    res.status(400).send({ message: "Content can not be empty!" });
    return;
  }

  // Create a User
  const scholarInfo = new CreateScholar({
    applicationDate: req.body.applicationDate,
    cardNumber: req.body.cardNumber,
    childFirstName: req.body.childFirstName,
    childFirstEdu1: req.body.childFirstEdu1,
    childFirstEdu2: req.body.childFirstEdu2,
    childSecondName: req.body.childSecondName,
    childSecondEdu1: req.body.childSecondEdu1,
    childSecondEdu2: req.body.childSecondEdu2,
    parentName: req.body.parentName,
    userId: req.body.userId,
  });

  // Save User in the database
  scholarInfo
    .save(scholarInfo)
    .then((data) => {
      res.send(data);
    })
    .catch((err) => {
      res.status(500).send({
        message:
          err.message ||
          "Some error occurred while creating the Scholarship data.",
      });
    });
};

// Retrieve all Tutorials from the database.
exports.findAll = (req, res) => {
  const name = req.query.name;
  let condition = name
    ? { name: { $regex: new RegExp(name), $options: "i" } }
    : {};

  CreateScholar.find(condition)
    .then((data) => {
      res.send(data);
    })
    .catch((err) => {
      res.status(500).send({
        message:
          err.message ||
          "Some error occurred while retrieving Scholarship data.",
      });
    });
};

// Find a single User with an id
// exports.findOne = (req, res) => {
//   const cardNumber = req.params.cardNumber;

//   CreateScholar.findById(cardNumber)
//     .then((data) => {
//       if (!data)
//         res.status(404).send({
//           message: "Not found Scholarship data with cardNumber " + cardNumber,
//         });
//       else res.send(data);
//     })
//     .catch((err) => {
//       res.status(500).send({
//         message:
//           "Error retrieving Scholarship data with cardNumber=" + cardNumber,
//       });
//     });
// };

exports.findOne = (req, res) => {
  const cardNumber = req.params.cardNumber;
  let condition = cardNumber
    ? { cardNumber: { $regex: new RegExp(cardNumber), $options: "i" } }
    : {};

  CreateScholar.find(condition)
    .then((data) => {
      res.send(data);
    })
    .catch((err) => {
      res.status(500).send({
        message:
          err.message ||
          "Some error occurred while retrieving Scholarship data with card number " +
            cardNumber,
      });
    });
};

// get inactive users account
exports.getInactive = (req, res) => {
  const status = "INACTIVE"; //req.query.status;
  let condition = status
    ? { status: { $regex: new RegExp(status), $options: "i" } }
    : {};

  CreateScholar.find(condition)
    .then((data) => {
      res.send(data);
    })
    .catch((err) => {
      res.status(500).send({
        message: err.message || "Some error occurred while retrieving Users.",
      });
    });
};

// Update a User by the id in the request
exports.update = (req, res) => {
  if (!req.body) {
    return res.status(400).send({
      message: "Data to update can not be empty!",
    });
  }

  const id = req.params.id;

  CreateScholar.findByIdAndUpdate(id, req.body, { useFindAndModify: false })
    .then((data) => {
      if (!data) {
        res.status(404).send({
          message: `Cannot update scholar with id=${id}. Maybe scholar was not found!`,
        });
      } else res.send({ message: "scholar was updated successfully." });
    })
    .catch((err) => {
      res.status(500).send({
        message: "Error updating scholar with id=" + id,
      });
    });
};

// Delete a User with the specified id in the request
exports.delete = (req, res) => {
  const id = req.params.id;

  CreateScholar.findByIdAndRemove(id)
    .then((data) => {
      if (!data) {
        res.status(404).send({
          message: `Cannot delete User with id=${id}. Maybe User was not found!`,
        });
      } else {
        res.send({
          message: "User was deleted successfully!",
        });
      }
    })
    .catch((err) => {
      res.status(500).send({
        message: "Could not delete User with id=" + id,
      });
    });
};

// Delete all Tutorials from the database.
exports.deleteAll = (req, res) => {
  CreateScholar.deleteMany({})
    .then((data) => {
      res.send({
        message: `${data.deletedCount} Users were deleted successfully!`,
      });
    })
    .catch((err) => {
      res.status(500).send({
        message: err.message || "Some error occurred while removing all users.",
      });
    });
};

// Find all published Tutorials
exports.findAllPublished = (req, res) => {
  CreateScholar.find({ published: true })
    .then((data) => {
      res.send(data);
    })
    .catch((err) => {
      res.status(500).send({
        message: err.message || "Some error occurred while retrieving users.",
      });
    });
};

// schedular
// var cron = require("node-schedule");
// /* run the job at 18:55:30 on Dec. 14 2018*/
// var date = new Date("0 9 19 5 wed");
// cron.scheduleJob(date, function () {
//   console.log(new Date(), "update age and status");
//   // get all users
//   // find inactive user by based on date

//   const data = {
//     id: "60a489c61fb94505078b54d3",
//     status: "INACTIVE",
//   };
//   updateStatus(data);
//   console.log("updated");
// });

// function updateStatus(data) {
//   CreateScholar.findByIdAndUpdate(data.id, data, { useFindAndModify: false })
//     .then((data) => {
//       if (!data) {
//         console.log("no record found");
//       }
//     })
//     .catch((err) => {
//       console.log(err);
//     });
// }

// find inactive user by date
// function getExpirdeAccount(dateString) {
//   var today = new Date();
//   var expDate = new Date(dateString);
//   var yr = expDate.getFullYear() - today.getFullYear();
//   var m = expDate.getMonth() - today.getMonth();
//   var day = expDate.getDate() - today.getDate();
//   if (yr === 0 && m === 0 && day < 0) {
//     return true;
//   } else {
//     return false;
//   }
// }
