const db = require("../models");
const CreateUser = db.userinfo;

// Create and Save a new User
exports.create = (req, res) => {
  // Validate request
  if (!req.body.name) {
    res.status(400).send({ message: "Content can not be empty!" });
    return;
  }

  function getAge(dateString) {
    var today = new Date();
    var birthDate = new Date(dateString);
    var age = today.getFullYear() - birthDate.getFullYear();
    var m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    return age;
  }
  // Create a User
  const userInfo = new CreateUser({
    name: req.body.name,
    dateOfBirth: req.body.dateOfBirth,
    phoneNumber: req.body.phoneNumber,
    cardNumber: req.body.cardNumber,
    expiryDate: req.body.expiryDate,
    status: "PENDING",
    age: getAge(req.body.dateOfBirth),
  });

  // Save User in the database
  userInfo
    .save(userInfo)
    .then((data) => {
      res.send(data);
    })
    .catch((err) => {
      res.status(500).send({
        message: err.message || "Some error occurred while creating the User.",
      });
    });
};

// Retrieve all Tutorials from the database.
exports.findAll = (req, res) => {
  const name = req.query.name;
  let condition = name
    ? { name: { $regex: new RegExp(name), $options: "i" } }
    : {};

  CreateUser.find(condition)
    .then((data) => {
      res.send(data);
    })
    .catch((err) => {
      res.status(500).send({
        message: err.message || "Some error occurred while retrieving Users.",
      });
    });
};

// Find a single User with an id
exports.findOne = (req, res) => {
  const id = req.params.id;

  CreateUser.findById(id)
    .then((data) => {
      if (!data)
        res.status(404).send({ message: "Not found User with id " + id });
      else res.send(data);
    })
    .catch((err) => {
      res.status(500).send({ message: "Error retrieving User with id=" + id });
    });
};

exports.findExpiring = (req, res) => {
  const condition = {};

  function fnExpiring(dateString) {
    var today = new Date();
    var expDate = new Date(dateString);
    var yr = expDate.getFullYear() - today.getFullYear();
    var m = expDate.getMonth() - today.getMonth();
    var day = expDate.getDate() - today.getDate();
    if (yr === 0 && m === 0 && day <= 30 && day >= 0) {
      return true;
    } else {
      return false;
    }
  }

  CreateUser.find(condition)
    .then((data) => {
      if (data) {
        var filt = data.filter((item) => fnExpiring(item.expiryDate));
        res.send(filt);
      }
    })
    .catch((err) => {
      res.status(500).send({
        message: err.message || "Some error occurred while retrieving Users.",
      });
    });
};

// get inactive users account
exports.getInactive = (req, res) => {
  const status = "INACTIVE"; //req.query.status;
  let condition = status
    ? { status: { $regex: new RegExp(status), $options: "i" } }
    : {};

  CreateUser.find(condition)
    .then((data) => {
      res.send(data);
    })
    .catch((err) => {
      res.status(500).send({
        message: err.message || "Some error occurred while retrieving Users.",
      });
    });
};

// Update a User by the id in the request
exports.update = (req, res) => {
  if (!req.body) {
    return res.status(400).send({
      message: "Data to update can not be empty!",
    });
  }

  const id = req.params.id;

  CreateUser.findByIdAndUpdate(id, req.body, { useFindAndModify: false })
    .then((data) => {
      if (!data) {
        res.status(404).send({
          message: `Cannot update User with id=${id}. Maybe User was not found!`,
        });
      } else res.send({ message: "User was updated successfully." });
    })
    .catch((err) => {
      res.status(500).send({
        message: "Error updating User with id=" + id,
      });
    });
};

// Delete a User with the specified id in the request
exports.delete = (req, res) => {
  const id = req.params.id;

  CreateUser.findByIdAndRemove(id)
    .then((data) => {
      if (!data) {
        res.status(404).send({
          message: `Cannot delete User with id=${id}. Maybe User was not found!`,
        });
      } else {
        res.send({
          message: "User was deleted successfully!",
        });
      }
    })
    .catch((err) => {
      res.status(500).send({
        message: "Could not delete User with id=" + id,
      });
    });
};

// Delete all Tutorials from the database.
exports.deleteAll = (req, res) => {
  CreateUser.deleteMany({})
    .then((data) => {
      res.send({
        message: `${data.deletedCount} Users were deleted successfully!`,
      });
    })
    .catch((err) => {
      res.status(500).send({
        message: err.message || "Some error occurred while removing all users.",
      });
    });
};

// Find all published Tutorials
exports.findAllPublished = (req, res) => {
  CreateUser.find({ published: true })
    .then((data) => {
      res.send(data);
    })
    .catch((err) => {
      res.status(500).send({
        message: err.message || "Some error occurred while retrieving users.",
      });
    });
};

// schedular
// var cron = require("node-schedule");
// /* run the job at 18:55:30 on Dec. 14 2018*/
// var date = new Date("0 9 19 5 wed");
// cron.scheduleJob(date, function () {
//   console.log(new Date(), "update age and status");
//   // get all users
//   // find inactive user by based on date

//   const data = {
//     id: "60a489c61fb94505078b54d3",
//     status: "INACTIVE",
//   };
//   updateStatus(data);
//   console.log("updated");
// });

// function updateStatus(data) {
//   CreateUser.findByIdAndUpdate(data.id, data, { useFindAndModify: false })
//     .then((data) => {
//       if (!data) {
//         console.log("no record found");
//       }
//     })
//     .catch((err) => {
//       console.log(err);
//     });
// }

// find inactive user by date
// function getExpirdeAccount(dateString) {
//   var today = new Date();
//   var expDate = new Date(dateString);
//   var yr = expDate.getFullYear() - today.getFullYear();
//   var m = expDate.getMonth() - today.getMonth();
//   var day = expDate.getDate() - today.getDate();
//   if (yr === 0 && m === 0 && day < 0) {
//     return true;
//   } else {
//     return false;
//   }
// }
