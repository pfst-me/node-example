module.exports = (mongoose) => {
  var schema = mongoose.Schema(
    {
      applicationDate: Date,
      cardNumber: String,
      childFirstEdu1: String,
      childFirstEdu2: String,
      childFirstName: String,
      childSecondEdu1: String,
      childSecondEdu2: String,
      childSecondName: String,
      id: String,
      parentName: String,
      userId: String,
    },
    { timestamps: true }
  );

  schema.method("toJSON", function () {
    const { __v, _id, ...object } = this.toObject();
    object.id = _id;
    return object;
  });

  const CreateScholarship = mongoose.model("scholarinfo", schema);
  return CreateScholarship;
};
