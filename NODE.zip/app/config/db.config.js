module.exports = {
  url: `mongodb+srv://bmsadmin:8DIlVpanZHVxtMXx@cluster0.zwj51.mongodb.net/bms`,
};
